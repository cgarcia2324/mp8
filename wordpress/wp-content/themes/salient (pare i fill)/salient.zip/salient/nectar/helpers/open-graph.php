<?php
/**
 * Open graph default tags
 *
 * @package Salient WordPress Theme
 * @subpackage helpers
 * @version 10.5
 * @deprecated 10.5
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

