<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="8" y="33" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="48" height="30"/>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M16,33V17c0-8.837,7.163-16,16-16s16,7.163,16,16v3
		"/>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="47" r="4"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="51" x2="32" y2="55"/>
</g>
</svg>
