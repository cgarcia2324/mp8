<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="14" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="36" height="4"/>
<rect x="14" y="59" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="36" height="4"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M18,59c0,0,0-8,0-14s29-19,29-25c0-2,0-15,0-15"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M47,59c0,0,0-8,0-14S18,26,18,20c0-2,0-15,0-15"/>
</svg>
